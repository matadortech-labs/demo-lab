# Keyfactor Command branded NGINX certificate status subpage v2

Installs a Keyfactor Command branded subpage at `/keyfactor/` without modifying the default MatadorTech home page.

The page uses the existing live certificate CGI endpoint at `/cgi-bin/cert-info.cgi` and keeps the header color set to `#5F61FF`.

## Install

```bash
unzip nginx-keyfactor-subpage-v2.zip
cd nginx-keyfactor-subpage-v2
sudo WEB_ROOT=/var/www/html ./install.sh
sudo nginx -t
sudo systemctl reload nginx
```

Open: `https://lab-nginx01.corp.matadortech.net/keyfactor/`
